package my.cajeroVista;

import javax.swing.ImageIcon;
import my.cajeroModelo.ModeloC;

/**
 *
 * @author Oscar Saez Gonzalez
 * @author Jacobo Muñoz Martinez
 * 
 * Clase que contiene la interfaz grafica del programa
 */
public class VistaC extends javax.swing.JFrame {
    
    private ModeloC modelo = new ModeloC();
    private ControladorC controlador = new ControladorC(modelo, this);
    
    /**
     * Constructor de la clase VistaC
     */
    public VistaC() {
        initComponents();
        setEnabledAllButtons(false);
    }
    
    /**
     * Modifica el texto que muestra el boton de la tarjeta
     * @param s (texto modificado)
     */
    public void setTextoToggleButtonTarjeta(String s){
        toggleButtonTarjeta.setText(s);
    }
    
    /**
     * Modifica el texto que muestra la pantalla del cajero
     * @param s (texto modificado)
     */
    public void setTextPantalla(String s){
        textPantalla.setText(s);
    }
    
    /**
     * Modifica el texto que muestra la salida de dinero
     * @param s (texto modificado)
     */
    public void setTextDinero(String s){
        textDinero.setText(s);
    }
    
    /**
     * Modifica el texto que muestra la lista de transacciones
     * @param s (transaccion)
     */
    public void setTextTransacciones(String s){
       textTransatlantico.append(s);
       textTransatlantico.append(System.getProperty("line.separator"));
    }
    
    /**
     * Modifica el icono de dineroCayendo1 y dineroCayendo2
     * @param s (icono)
     */
    public void setDineroCayendo(String s){
        ImageIcon icon = new ImageIcon(s);
        dineroCayendo1.setIcon(icon);
        dineroCayendo2.setIcon(icon);
    }
    
    /**
     * Deja de mostrar el icono de dineroCayendo1 y dineroCayendo2
     */
    public void setNullDineroCayendo(){
        dineroCayendo1.setIcon(null);
        dineroCayendo2.setIcon(null);
    }
    
    /**
     * Modifica el icono de imagenTarjeta
     * @param s (icono)
     */
    public void setImagenTarjeta(String s){
        ImageIcon icon = new ImageIcon(s);
        imagenTarjeta.setIcon(icon);
    }
    
    /**
     * Deja de mostrar el icono de imagenTarjeta
     */
    public void setNullImagenTarjeta(){
        imagenTarjeta.setIcon(null);
    }
    
    /**
     * Modifica el estado de todos los botones, excepto el de la tarjeta
     * para que se puedan o no pulsar
     * @param b 
     */
    public void setEnabledAllButtons(boolean b){
        botonUno.setEnabled(b);
        botonDos.setEnabled(b);
        botonTres.setEnabled(b);
        botonCuatro.setEnabled(b);
        botonCinco.setEnabled(b);
        botonSeis.setEnabled(b);
        botonSiete.setEnabled(b);
        botonOcho.setEnabled(b);
        botonNueve.setEnabled(b);
        botonCero.setEnabled(b);
        botonAceptar.setEnabled(b);
        botonCancelar.setEnabled(b);
        botonBorrar.setEnabled(b);
        botonConsultarSaldo.setEnabled(b);
        botonRetirarDinero.setEnabled(b);
        botonConsultarTrans.setEnabled(b);
        botonSalir.setEnabled(b);
    }
    
    /**
     * Modifica el estado de todos los botones numericos, aceptar, borrar y cancelar
     * para que se puedan pulsar
     */
    public void setEnabledNumButtons(){
        botonUno.setEnabled(true);
        botonDos.setEnabled(true);
        botonTres.setEnabled(true);
        botonCuatro.setEnabled(true);
        botonCinco.setEnabled(true);
        botonSeis.setEnabled(true);
        botonSiete.setEnabled(true);
        botonOcho.setEnabled(true);
        botonNueve.setEnabled(true);
        botonCero.setEnabled(true);
        botonAceptar.setEnabled(true);
        botonCancelar.setEnabled(true);
        botonBorrar.setEnabled(true);
    }
    
    /**
     * Vacia el cuadro de texto de las transacciones
     */
    public void clearTextTransacciones(){
        textTransatlantico.setText("");
    }
    
    /**
     * Muestra las etiquetas de los botones de las operaciones del cajero
     */
    public void activarLabels(){
        labelRD.setText("Retirar dinero");
        labelCT.setText("Consulta transacciones");
        labelCS.setText("Consultar Saldo");
        labelS.setText("Salir");
    }
    
    /**
     * Deja de mostrar las etiquetas de los botones de las operaciones del cajero
     */
    public void desactivarLabels(){
        labelRD.setText("");
        labelCT.setText("");
        labelCS.setText("");
        labelS.setText("");
    }
    
    /**
     * Cambia el estado de toggleButtonTarjeta a no seleccionado
     */
    public void cambiarEstadoToggleButton(){
        toggleButtonTarjeta.setSelected(false); 
    }
    
    /**
     * Modifica el estado del boton de la tarjeta para que se pueda o no pulsar
     * @param b 
     */
    public void setEnabledToggleButtonTarjeta(boolean b){
        toggleButtonTarjeta.setEnabled(b);
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel26 = new javax.swing.JPanel();
        toggleButtonTarjeta = new javax.swing.JToggleButton();
        jPanel27 = new javax.swing.JPanel();
        imagenTarjeta = new javax.swing.JLabel();
        jPanel28 = new javax.swing.JPanel();
        jPanel29 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        textTransatlantico = new javax.swing.JTextArea();
        jPanel30 = new javax.swing.JPanel();
        jPanel31 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        textPantalla = new javax.swing.JTextField();
        jPanel9 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        botonRetirarDinero = new javax.swing.JButton();
        labelRD = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        botonConsultarTrans = new javax.swing.JButton();
        labelCT = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        labelCS = new javax.swing.JLabel();
        botonConsultarSaldo = new javax.swing.JButton();
        jPanel21 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        labelS = new javax.swing.JLabel();
        botonSalir = new javax.swing.JButton();
        jPanel23 = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jPanel32 = new javax.swing.JPanel();
        dineroCayendo2 = new javax.swing.JLabel();
        jPanel37 = new javax.swing.JPanel();
        jPanel38 = new javax.swing.JPanel();
        textDinero = new javax.swing.JTextField();
        jPanel39 = new javax.swing.JPanel();
        dineroCayendo1 = new javax.swing.JLabel();
        jPanel33 = new javax.swing.JPanel();
        jPanel34 = new javax.swing.JPanel();
        jPanel35 = new javax.swing.JPanel();
        jPanel36 = new javax.swing.JPanel();
        jPanel25 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        botonUno = new javax.swing.JButton();
        botonDos = new javax.swing.JButton();
        botonTres = new javax.swing.JButton();
        botonCancelar = new javax.swing.JButton();
        botonCuatro = new javax.swing.JButton();
        botonCinco = new javax.swing.JButton();
        botonSeis = new javax.swing.JButton();
        botonBorrar = new javax.swing.JButton();
        botonSiete = new javax.swing.JButton();
        botonOcho = new javax.swing.JButton();
        botonNueve = new javax.swing.JButton();
        jPanel42 = new javax.swing.JPanel();
        jPanel43 = new javax.swing.JPanel();
        botonCero = new javax.swing.JButton();
        jPanel44 = new javax.swing.JPanel();
        botonAceptar = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setPreferredSize(new java.awt.Dimension(250, 476));
        jPanel1.setLayout(new java.awt.GridLayout(8, 0));

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 250, Short.MAX_VALUE)
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 111, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel26);

        toggleButtonTarjeta.setText("Sin Tarjeta");
        toggleButtonTarjeta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toggleButtonTarjetaActionPerformed(evt);
            }
        });
        jPanel1.add(toggleButtonTarjeta);

        jPanel27.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel27.add(imagenTarjeta, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 250, 110));

        jPanel1.add(jPanel27);

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 250, Short.MAX_VALUE)
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 111, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel28);

        javax.swing.GroupLayout jPanel29Layout = new javax.swing.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 250, Short.MAX_VALUE)
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 111, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel29);

        textTransatlantico.setEditable(false);
        textTransatlantico.setColumns(20);
        textTransatlantico.setRows(5);
        jScrollPane1.setViewportView(textTransatlantico);

        jPanel1.add(jScrollPane1);

        javax.swing.GroupLayout jPanel30Layout = new javax.swing.GroupLayout(jPanel30);
        jPanel30.setLayout(jPanel30Layout);
        jPanel30Layout.setHorizontalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 250, Short.MAX_VALUE)
        );
        jPanel30Layout.setVerticalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 111, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel30);

        javax.swing.GroupLayout jPanel31Layout = new javax.swing.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 250, Short.MAX_VALUE)
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 111, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel31);

        getContentPane().add(jPanel1, java.awt.BorderLayout.LINE_END);

        jPanel2.setLayout(new java.awt.GridLayout(2, 0));

        jPanel4.setLayout(new java.awt.BorderLayout());

        jPanel10.setLayout(new java.awt.BorderLayout());

        jPanel12.setPreferredSize(new java.awt.Dimension(306, 475));
        jPanel12.setLayout(new java.awt.BorderLayout());

        textPantalla.setEditable(false);
        textPantalla.setBackground(new java.awt.Color(255, 255, 255));
        textPantalla.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        textPantalla.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        textPantalla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textPantallaActionPerformed(evt);
            }
        });
        jPanel12.add(textPantalla, java.awt.BorderLayout.CENTER);

        jPanel9.setBackground(new java.awt.Color(51, 51, 51));
        jPanel9.setPreferredSize(new java.awt.Dimension(200, 349));
        jPanel9.setLayout(new java.awt.GridLayout(6, 0));

        jPanel13.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 200, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 74, Short.MAX_VALUE)
        );

        jPanel9.add(jPanel13);

        jPanel14.setBackground(new java.awt.Color(0, 0, 0));
        jPanel14.setLayout(new java.awt.GridLayout(1, 2));

        botonRetirarDinero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonRetirarDineroActionPerformed(evt);
            }
        });
        jPanel14.add(botonRetirarDinero);

        labelRD.setForeground(new java.awt.Color(255, 255, 255));
        labelRD.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel14.add(labelRD);

        jPanel9.add(jPanel14);

        jPanel15.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 200, Short.MAX_VALUE)
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 74, Short.MAX_VALUE)
        );

        jPanel9.add(jPanel15);

        jPanel16.setBackground(new java.awt.Color(0, 0, 0));
        jPanel16.setLayout(new java.awt.GridLayout(1, 2));

        botonConsultarTrans.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonConsultarTransActionPerformed(evt);
            }
        });
        jPanel16.add(botonConsultarTrans);

        labelCT.setForeground(new java.awt.Color(255, 255, 255));
        labelCT.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel16.add(labelCT);

        jPanel9.add(jPanel16);

        jPanel17.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 200, Short.MAX_VALUE)
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 74, Short.MAX_VALUE)
        );

        jPanel9.add(jPanel17);

        jPanel18.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 200, Short.MAX_VALUE)
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 74, Short.MAX_VALUE)
        );

        jPanel9.add(jPanel18);

        jPanel12.add(jPanel9, java.awt.BorderLayout.LINE_START);

        jPanel8.setBackground(new java.awt.Color(51, 51, 51));
        jPanel8.setPreferredSize(new java.awt.Dimension(200, 349));
        jPanel8.setLayout(new java.awt.GridLayout(6, 0));

        jPanel19.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 200, Short.MAX_VALUE)
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 74, Short.MAX_VALUE)
        );

        jPanel8.add(jPanel19);

        jPanel20.setBackground(new java.awt.Color(0, 0, 0));
        jPanel20.setLayout(new java.awt.GridLayout(1, 2));

        labelCS.setForeground(new java.awt.Color(255, 255, 255));
        labelCS.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel20.add(labelCS);

        botonConsultarSaldo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonConsultarSaldoActionPerformed(evt);
            }
        });
        jPanel20.add(botonConsultarSaldo);

        jPanel8.add(jPanel20);

        jPanel21.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 200, Short.MAX_VALUE)
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 74, Short.MAX_VALUE)
        );

        jPanel8.add(jPanel21);

        jPanel22.setBackground(new java.awt.Color(0, 0, 0));
        jPanel22.setLayout(new java.awt.GridLayout(1, 2));

        labelS.setForeground(new java.awt.Color(255, 255, 255));
        labelS.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel22.add(labelS);

        botonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSalirActionPerformed(evt);
            }
        });
        jPanel22.add(botonSalir);

        jPanel8.add(jPanel22);

        jPanel23.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 200, Short.MAX_VALUE)
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 74, Short.MAX_VALUE)
        );

        jPanel8.add(jPanel23);

        jPanel24.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 200, Short.MAX_VALUE)
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 74, Short.MAX_VALUE)
        );

        jPanel8.add(jPanel24);

        jPanel12.add(jPanel8, java.awt.BorderLayout.LINE_END);

        jPanel10.add(jPanel12, java.awt.BorderLayout.CENTER);

        jPanel4.add(jPanel10, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel4);

        jPanel3.setLayout(new java.awt.GridLayout(2, 3));

        jPanel11.setPreferredSize(new java.awt.Dimension(523, 50));
        jPanel11.setLayout(new java.awt.GridLayout(2, 0));

        jPanel32.setLayout(new java.awt.GridLayout(1, 3));

        dineroCayendo2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel32.add(dineroCayendo2);

        jPanel37.setLayout(new java.awt.GridLayout(3, 0));

        javax.swing.GroupLayout jPanel38Layout = new javax.swing.GroupLayout(jPanel38);
        jPanel38.setLayout(jPanel38Layout);
        jPanel38Layout.setHorizontalGroup(
            jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 314, Short.MAX_VALUE)
        );
        jPanel38Layout.setVerticalGroup(
            jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 37, Short.MAX_VALUE)
        );

        jPanel37.add(jPanel38);

        textDinero.setEditable(false);
        textDinero.setBackground(new java.awt.Color(255, 255, 255));
        textDinero.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        textDinero.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel37.add(textDinero);

        javax.swing.GroupLayout jPanel39Layout = new javax.swing.GroupLayout(jPanel39);
        jPanel39.setLayout(jPanel39Layout);
        jPanel39Layout.setHorizontalGroup(
            jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 314, Short.MAX_VALUE)
        );
        jPanel39Layout.setVerticalGroup(
            jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 37, Short.MAX_VALUE)
        );

        jPanel37.add(jPanel39);

        jPanel32.add(jPanel37);

        dineroCayendo1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel32.add(dineroCayendo1);

        jPanel11.add(jPanel32);

        jPanel33.setLayout(new java.awt.GridLayout(3, 0));

        jPanel34.setBackground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout jPanel34Layout = new javax.swing.GroupLayout(jPanel34);
        jPanel34.setLayout(jPanel34Layout);
        jPanel34Layout.setHorizontalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 943, Short.MAX_VALUE)
        );
        jPanel34Layout.setVerticalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 37, Short.MAX_VALUE)
        );

        jPanel33.add(jPanel34);

        jPanel35.setBackground(new java.awt.Color(153, 153, 153));

        javax.swing.GroupLayout jPanel35Layout = new javax.swing.GroupLayout(jPanel35);
        jPanel35.setLayout(jPanel35Layout);
        jPanel35Layout.setHorizontalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 943, Short.MAX_VALUE)
        );
        jPanel35Layout.setVerticalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 37, Short.MAX_VALUE)
        );

        jPanel33.add(jPanel35);

        jPanel36.setBackground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout jPanel36Layout = new javax.swing.GroupLayout(jPanel36);
        jPanel36.setLayout(jPanel36Layout);
        jPanel36Layout.setHorizontalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 943, Short.MAX_VALUE)
        );
        jPanel36Layout.setVerticalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 37, Short.MAX_VALUE)
        );

        jPanel33.add(jPanel36);

        jPanel11.add(jPanel33);

        jPanel3.add(jPanel11);

        jPanel25.setLayout(new java.awt.GridLayout(1, 3));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 314, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 222, Short.MAX_VALUE)
        );

        jPanel25.add(jPanel5);

        jPanel6.setLayout(new java.awt.GridLayout(4, 4));

        botonUno.setText("1");
        botonUno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonUnoActionPerformed(evt);
            }
        });
        jPanel6.add(botonUno);

        botonDos.setText("2");
        botonDos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonDosActionPerformed(evt);
            }
        });
        jPanel6.add(botonDos);

        botonTres.setText("3");
        botonTres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonTresActionPerformed(evt);
            }
        });
        jPanel6.add(botonTres);

        botonCancelar.setBackground(new java.awt.Color(255, 0, 0));
        botonCancelar.setText("Cancelar");
        botonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCancelarActionPerformed(evt);
            }
        });
        jPanel6.add(botonCancelar);

        botonCuatro.setText("4");
        botonCuatro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCuatroActionPerformed(evt);
            }
        });
        jPanel6.add(botonCuatro);

        botonCinco.setText("5");
        botonCinco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCincoActionPerformed(evt);
            }
        });
        jPanel6.add(botonCinco);

        botonSeis.setText("6");
        botonSeis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSeisActionPerformed(evt);
            }
        });
        jPanel6.add(botonSeis);

        botonBorrar.setBackground(new java.awt.Color(255, 255, 0));
        botonBorrar.setText("Borrar");
        botonBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBorrarActionPerformed(evt);
            }
        });
        jPanel6.add(botonBorrar);

        botonSiete.setText("7");
        botonSiete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSieteActionPerformed(evt);
            }
        });
        jPanel6.add(botonSiete);

        botonOcho.setText("8");
        botonOcho.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonOchoActionPerformed(evt);
            }
        });
        jPanel6.add(botonOcho);

        botonNueve.setText("9");
        botonNueve.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonNueveActionPerformed(evt);
            }
        });
        jPanel6.add(botonNueve);

        javax.swing.GroupLayout jPanel42Layout = new javax.swing.GroupLayout(jPanel42);
        jPanel42.setLayout(jPanel42Layout);
        jPanel42Layout.setHorizontalGroup(
            jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 78, Short.MAX_VALUE)
        );
        jPanel42Layout.setVerticalGroup(
            jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 55, Short.MAX_VALUE)
        );

        jPanel6.add(jPanel42);

        javax.swing.GroupLayout jPanel43Layout = new javax.swing.GroupLayout(jPanel43);
        jPanel43.setLayout(jPanel43Layout);
        jPanel43Layout.setHorizontalGroup(
            jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 78, Short.MAX_VALUE)
        );
        jPanel43Layout.setVerticalGroup(
            jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 55, Short.MAX_VALUE)
        );

        jPanel6.add(jPanel43);

        botonCero.setText("0");
        botonCero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCeroActionPerformed(evt);
            }
        });
        jPanel6.add(botonCero);

        javax.swing.GroupLayout jPanel44Layout = new javax.swing.GroupLayout(jPanel44);
        jPanel44.setLayout(jPanel44Layout);
        jPanel44Layout.setHorizontalGroup(
            jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 78, Short.MAX_VALUE)
        );
        jPanel44Layout.setVerticalGroup(
            jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 55, Short.MAX_VALUE)
        );

        jPanel6.add(jPanel44);

        botonAceptar.setBackground(new java.awt.Color(0, 153, 51));
        botonAceptar.setText("Aceptar");
        botonAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAceptarActionPerformed(evt);
            }
        });
        jPanel6.add(botonAceptar);

        jPanel25.add(jPanel6);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 314, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 222, Short.MAX_VALUE)
        );

        jPanel25.add(jPanel7);

        jPanel3.add(jPanel25);

        jPanel2.add(jPanel3);

        getContentPane().add(jPanel2, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void textPantallaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textPantallaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textPantallaActionPerformed

    /**
     * Evento que se produce al pulsar el boton "5"
     * @param evt 
     */
    private void botonCincoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCincoActionPerformed
        controlador.procesarEventoBotonNum("5");
    }//GEN-LAST:event_botonCincoActionPerformed

    /**
     * Evento que se produce al pulsar el boton "Consultar Saldo"
     * @param evt 
     */
    private void botonConsultarSaldoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonConsultarSaldoActionPerformed
        controlador.procesarEventoBotonConsultarSaldo();
    }//GEN-LAST:event_botonConsultarSaldoActionPerformed

    /**
     * Evento que se produce al pulsar el boton de la tarjeta
     * @param evt 
     */
    private void toggleButtonTarjetaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toggleButtonTarjetaActionPerformed
        controlador.procesarEventoTarjeta();
    }//GEN-LAST:event_toggleButtonTarjetaActionPerformed

    /**
     * Evento que se produce al pulsar el boton "1"
     * @param evt 
     */
    private void botonUnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonUnoActionPerformed
        controlador.procesarEventoBotonNum("1");
    }//GEN-LAST:event_botonUnoActionPerformed

    /**
     * Evento que se produce al pulsar el boton "Aceptar"
     * @param evt 
     */
    private void botonAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAceptarActionPerformed
        controlador.procesarEventoBotonAceptar();
    }//GEN-LAST:event_botonAceptarActionPerformed

    /**
     * Evento que se produce al pulsar el boton "2"
     * @param evt 
     */
    private void botonDosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonDosActionPerformed
        controlador.procesarEventoBotonNum("2");
    }//GEN-LAST:event_botonDosActionPerformed

    /**
     * Evento que se produce al pulsar el boton "3"
     * @param evt 
     */
    private void botonTresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonTresActionPerformed
        controlador.procesarEventoBotonNum("3");
    }//GEN-LAST:event_botonTresActionPerformed

    /**
     * Evento que se produce al pulsar el boton "4"
     * @param evt 
     */
    private void botonCuatroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCuatroActionPerformed
        controlador.procesarEventoBotonNum("4");
    }//GEN-LAST:event_botonCuatroActionPerformed

    /**
     * Evento que se produce al pulsar el boton "6"
     * @param evt 
     */
    private void botonSeisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSeisActionPerformed
        controlador.procesarEventoBotonNum("6");
    }//GEN-LAST:event_botonSeisActionPerformed

    /**
     * Evento que se produce al pulsar el boton "7"
     * @param evt 
     */
    private void botonSieteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSieteActionPerformed
        controlador.procesarEventoBotonNum("7");
    }//GEN-LAST:event_botonSieteActionPerformed

    /**
     * Evento que se produce al pulsar el boton "8"
     * @param evt 
     */
    private void botonOchoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonOchoActionPerformed
        controlador.procesarEventoBotonNum("8");
    }//GEN-LAST:event_botonOchoActionPerformed

    /**
     * Evento que se produce al pulsar el boton "9"
     * @param evt 
     */
    private void botonNueveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonNueveActionPerformed
        controlador.procesarEventoBotonNum("9");
    }//GEN-LAST:event_botonNueveActionPerformed

    /**
     * Evento que se produce al pulsar el boton "0"
     * @param evt 
     */
    private void botonCeroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCeroActionPerformed
        controlador.procesarEventoBotonNum("0");
    }//GEN-LAST:event_botonCeroActionPerformed

    /**
     * Evento que se produce al pulsar el boton "Cancelar"
     * @param evt 
     */
    private void botonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCancelarActionPerformed
        controlador.procesarEventoBotonCancelar();
    }//GEN-LAST:event_botonCancelarActionPerformed

    /**
     * Evento que se produce al pulsar el boton "Borrar"
     * @param evt 
     */
    private void botonBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBorrarActionPerformed
        controlador.procesarEventoBotonBorrar();
    }//GEN-LAST:event_botonBorrarActionPerformed

    /**
     * Evento que se produce al pulsar el boton "Retirar Dinero"
     * @param evt 
     */
    private void botonRetirarDineroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonRetirarDineroActionPerformed
        controlador.procesarEventoBotonRetirarDinero();
    }//GEN-LAST:event_botonRetirarDineroActionPerformed

    /**
     * Evento que se produce al pulsar el boton "Consultar Transaccion"
     * @param evt 
     */
    private void botonConsultarTransActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonConsultarTransActionPerformed
        controlador.procesarEventoBotonConsultarTransacciones();
    }//GEN-LAST:event_botonConsultarTransActionPerformed

    /**
     * Evento que se produce al pulsar el boton "Salir"
     * @param evt 
     */
    private void botonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSalirActionPerformed
        controlador.procesarEventoBotonSalir();
    }//GEN-LAST:event_botonSalirActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonAceptar;
    private javax.swing.JButton botonBorrar;
    private javax.swing.JButton botonCancelar;
    private javax.swing.JButton botonCero;
    private javax.swing.JButton botonCinco;
    private javax.swing.JButton botonConsultarSaldo;
    private javax.swing.JButton botonConsultarTrans;
    private javax.swing.JButton botonCuatro;
    private javax.swing.JButton botonDos;
    private javax.swing.JButton botonNueve;
    private javax.swing.JButton botonOcho;
    private javax.swing.JButton botonRetirarDinero;
    private javax.swing.JButton botonSalir;
    private javax.swing.JButton botonSeis;
    private javax.swing.JButton botonSiete;
    private javax.swing.JButton botonTres;
    private javax.swing.JButton botonUno;
    private javax.swing.JLabel dineroCayendo1;
    private javax.swing.JLabel dineroCayendo2;
    private javax.swing.JLabel imagenTarjeta;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel42;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel44;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelCS;
    private javax.swing.JLabel labelCT;
    private javax.swing.JLabel labelRD;
    private javax.swing.JLabel labelS;
    private javax.swing.JTextField textDinero;
    private javax.swing.JTextField textPantalla;
    private javax.swing.JTextArea textTransatlantico;
    private javax.swing.JToggleButton toggleButtonTarjeta;
    // End of variables declaration//GEN-END:variables
}
