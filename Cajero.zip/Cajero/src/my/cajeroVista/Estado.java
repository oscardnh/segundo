/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.cajeroVista;

/**
 *
 * @author Oscar Saez Gonzalez
 * @author Jacobo Muñoz Martinez
 * 
 * Clase enum que contiene los diferentes estados en los que puede encontrarse el programa
 */
public enum Estado {
    SIN_TARJETA,
    CON_TARJETA, 
    MUESTRA_OPCIONES,
    RETIRAR_DINERO,
    CONSULTAR_SALDO,
    CONSULTAR_TRANSACCIONES;
}
