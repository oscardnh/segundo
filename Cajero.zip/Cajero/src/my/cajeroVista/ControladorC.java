package my.cajeroVista;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.Timer;
import my.cajeroModelo.ModeloC;

/**
 *
 * @author Oscar Saez Gonzalez
 * @author Jacobo Muñoz Martinez
 * 
 * Clase que gestiona los distintos elementos de la clase VistaC
 */
public class ControladorC {
    
    private ModeloC modelo = new ModeloC();
    private VistaC vista;
    private Estado estado;
    private String pinUsuario;
    private int contadorIntentos;
    private boolean bloqueado;
    private Timer timer;
    private Timer timerDinero;
    private String dinero;
    
    /**
     * Constructor de la clase ControladorC
     * @param modelo
     * @param vista 
     */
    public ControladorC(ModeloC modelo, VistaC vista){
        this.modelo = modelo;
        this.vista = vista;
        estado = Estado.SIN_TARJETA;
        contadorIntentos = 3;
        pinUsuario = "";
        bloqueado = false;
        dinero = "";
        /*timer de 2 segundos al introducir el pin para mostrar las diferentes
        operaciones del cajero.*/
        timer = new Timer(1000, new ActionListener() {
            int contadorActual = 1;
            public void actionPerformed(ActionEvent e) {
                // Aquí el código que queramos ejecutar.
                if (contadorActual >= 1) {
                    contadorActual--;
                } else {
                    timer.stop();
                    if(estado.equals(Estado.MUESTRA_OPCIONES)){
                        vista.setTextPantalla("Elija una opción");
                        vista.activarLabels();
                    }
                }
            }
        });
        //timer para mostrar el gif del dinero al retirar dinero
        timerDinero = new Timer(1000, new ActionListener() {
            int contadorActual = 3;
            public void actionPerformed(ActionEvent e) {
                // Aquí el código que queramos ejecutar.
                if (contadorActual >= 1) {
                    contadorActual--;
                } else {
                    timerDinero.stop();
                    if(estado.equals(Estado.MUESTRA_OPCIONES)){
                        vista.setTextPantalla("Elija una opción");
                        vista.setNullDineroCayendo();
                    }
                }
            }
        });
    }
    
    //Obtiene el pin introducido por el usuario
    private String getPinUsuario(){
        return pinUsuario;
    }
    
    //Modifica el pin introducido por el usuario
    private void setPinUsuario(String s){
        pinUsuario = s;
    }
    
    //Obtiene el dinero introducido por el usuario
    private String getDinero(){
        return dinero;
    }
    
    //Modifica el dinero introducido por el usuario
    private void setDinero(String s){
        dinero = s;
    }
    
    //Comprueba los intentos que le quedan al usuario de introducir el pin
    private void comprobarIntentos(){
        contadorIntentos--;
        vista.setTextPantalla("Tiene " + contadorIntentos + " intentos restantes");
        setPinUsuario("");
        if(contadorIntentos == 0){
            bloqueado = true;
            vista.setTextPantalla("Tarjeta bloqueada");
        }
    }
    
    /**
     * Funcion que se lleva a cabo cuando se pulsa el toggleButton toggleButtonTarjeta.
     * Si la aplicacion no esta bloqueada y sin tarjeta muestra en el boton de la tarjeta que
     * no hay tarjeta introducida y desactiva todos los botones y la imagen de la tarjeta.
     * Si tiene tarjeta pide al usuario el pin, muestra la imagen de la tarjeta introducida
     * y se deshabilita el boton de la tarjeta.
     */
    public void procesarEventoTarjeta(){
        if(!bloqueado){
            if(estado.equals(Estado.SIN_TARJETA)){
                estado = Estado.CON_TARJETA;
                vista.setTextoToggleButtonTarjeta("Tarjeta Introducida");
                vista.setTextPantalla("Introduzca el PIN de 4 digitos de la tarjeta");
                vista.setEnabledToggleButtonTarjeta(false);
                vista.setImagenTarjeta("diferencia-tarjeta-credito-debito.png");
                vista.setEnabledNumButtons();
            } else {
                estado = Estado.SIN_TARJETA;
                vista.setTextoToggleButtonTarjeta("Sin Tarjeta");
                vista.desactivarLabels();
                vista.setEnabledAllButtons(false);
                vista.setNullImagenTarjeta();
                vista.setTextPantalla("");
            }
        }
    }
    
    /**
     * Funcion que se lleva a cabo al pulsar alguno de los botones numericos.
     * Si la aplicacion no esta bloqueada, y el estado es sin tarjeta pide al usuario
     * por pantalla que introduzca la tarjeta.
     * Si el estado es con tarjeta coje los numeros que pulsa el usuario y los va mostrando
     * por pantalla.
     * Si el estado es retirar dinero coje los numeros que pulsa el usuario y los va 
     * mostrando por el cuadro de texto de abajo.
     * 
     * @param n (numero pulsado)
     */
    public void procesarEventoBotonNum(String n){
        if((!bloqueado) && (estado != Estado.MUESTRA_OPCIONES)){
            if(estado.equals(Estado.SIN_TARJETA)){
                vista.setTextPantalla("Introduzca una tarjeta");
            } else if(estado.equals(Estado.CON_TARJETA)){
                setPinUsuario(getPinUsuario()+n);
                vista.setTextPantalla(getPinUsuario());
            } else if(estado.equals(Estado.RETIRAR_DINERO)){
                setDinero(getDinero()+n);
                vista.setTextDinero(getDinero());
            }
        }
    }
    
    /**
     * Funcion que se lleva a cabo al pulsar el boton de aceptar.
     * Si el estado de la interfaz es sin tarjeta pide al usuario por pantalla que
     * introduzca la tarjeta.
     * Si el estado es con tarjeta se pide la introduccion del PIN al usuario.
     * Si el estado es retirar dinero se retira el dinero introducido por el usuario
     * si el numero introducido es multiplo de 10 y la cantidad no supera el saldo
     * de la tarjeta.
     */
    public void procesarEventoBotonAceptar(){
        if(estado.equals(Estado.SIN_TARJETA)){
            vista.setTextPantalla("Introduzca una tarjeta");
        } else if(estado.equals(Estado.CON_TARJETA)){
            if(pinUsuario.length() != 4){
                comprobarIntentos();
            } else {
                if(pinUsuario.equals(modelo.getPinCorrecto())){
                vista.setTextPantalla("PIN correcto");
                timer.start();
                vista.setEnabledAllButtons(true);
                estado = Estado.MUESTRA_OPCIONES;
                setPinUsuario("");
                } else {
                    comprobarIntentos();
                }
            }
        } else if(estado.equals(Estado.RETIRAR_DINERO)){
            int num = Integer.parseInt(dinero);
            if(num%10 != 0){
                vista.setTextPantalla("La cantidad introducida debe ser multiplo de 10");
            } else if(num > modelo.getSaldo()){
                vista.setTextPantalla("La cantidad introducida supera el saldo disponible");
            } else {
                modelo.setSaldo(modelo.getSaldo()-num);
                LocalDate fecha = LocalDate.now();
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                String fechaFormateada = fecha.format(formatter);
                modelo.addTransaccion("Retirada de " + dinero + "€ realizada el " + fechaFormateada);
                vista.setDineroCayendo("raining-money-37.gif");
                vista.setTextPantalla("Retire el dinero");
                estado = Estado.MUESTRA_OPCIONES;
                timerDinero.start();
            }
            vista.setTextDinero("");
            dinero = "";
        }
    }
    
    /**
     * Funcion que se lleva a cabo al pulsar el boton de borrar.
     * Si el estado de la interfaz es sin tarjeta pide al usuario por pantalla que
     * introduzca la tarjeta.
     * Si el estado es el que muestre las diferentes operaciones o que sea con tarjeta borra
     * el ultimo digito introducido por el usuario en la pantalla para meter el PIN.
     * Si el estado es el de retirar dinero, realiza lo mismo que antes pero en el cuadro
     * de texto de abajo.
     */
    public void procesarEventoBotonBorrar(){
        if(estado.equals(Estado.SIN_TARJETA)){
            vista.setTextPantalla("Introduzca una tarjeta");
        } else if((estado.equals(Estado.MUESTRA_OPCIONES)) || (estado.equals(Estado.CON_TARJETA))){
            pinUsuario = pinUsuario.substring(0, pinUsuario.length()-1);
            vista.setTextPantalla(pinUsuario);
        } else if(estado.equals(Estado.RETIRAR_DINERO)){
            dinero = dinero.substring(0, dinero.length()-1);
            vista.setTextDinero(dinero);
        }
    }
    
    /**
     * Funcion que se lleva a cabo al pulsar el boton de cancelar.
     * Si el estado de la interfaz es sin tarjeta pide al usuario por pantalla que
     * introduzca la tarjeta.
     * Si el estado es el de mostrar las diferentes operaciones pide al usuario que retire
     * la tarjeta.
     * Si no esta en ninguno de los estados anteriores se cambia al estado de mostrar
     * las diferentes operaciones y pide al usuario que elija una de ellas.
     */
    public void procesarEventoBotonCancelar(){
        if(estado.equals(Estado.SIN_TARJETA)){
            vista.setTextPantalla("Introduzca una tarjeta");
        } else if(estado.equals(Estado.MUESTRA_OPCIONES)){
            vista.setTextPantalla("Porfavor retire la tarjeta");
            vista.setEnabledToggleButtonTarjeta(true);
        } else {
            estado = Estado.MUESTRA_OPCIONES;
            vista.setTextPantalla("Elija opción");
            vista.desactivarLabels();
            vista.setTextDinero("");
        }
    }
    
    /**
     * Funcion que se lleva a cabo al pulsar el boton de retirar dinero.
     * Si el estado de la interfaz es sin tarjeta pide al usuario por pantalla que
     * introduzca la tarjeta.
     * Si no pide al usuario el dinero a retirar.
     */
    public void procesarEventoBotonRetirarDinero(){
        if(estado.equals(Estado.SIN_TARJETA)){
            vista.setTextPantalla("Introduzca una tarjeta");
        }else{
            vista.setTextPantalla("Introduzca el dinero que desea retirar");
            estado = Estado.RETIRAR_DINERO;
            vista.clearTextTransacciones();
        }
    }
    
    /**
     * Funcion que se lleva a cabo al pulsar el boton de consultar saldo.
     * Si el estado de la interfaz es sin tarjeta pide al usuario por pantalla que
     * introduzca la tarjeta.
     * Si no muestra el saldo restante de la tarjeta por pantalla.
     */
    public void procesarEventoBotonConsultarSaldo(){
        if(estado.equals(Estado.SIN_TARJETA)){
            vista.setTextPantalla("Introduzca una tarjeta");
        }else{
            vista.setTextPantalla(String.valueOf(modelo.getSaldo()) + "€");
            estado = Estado.CONSULTAR_SALDO;
            vista.clearTextTransacciones();
        }
    }
    
    /**
     * Funcion que se lleva a cabo al pulsar el boton de consultar transacciones.
     * Si el estado de la interfaz es sin tarjeta pide al usuario por pantalla que
     * introduzca la tarjeta.
     * Si el estado es cualquiera que no sea sin tarjeta imprime las transacciones.
     */
    public void procesarEventoBotonConsultarTransacciones(){
        if(estado.equals(Estado.SIN_TARJETA)){
            vista.setTextPantalla("Introduzca una tarjeta");
        }else{
            vista.clearTextTransacciones();
            for(int i = modelo.getTransacciones().size()-1; i >= 0; i--){
                vista.setTextTransacciones(modelo.getTransacciones().get(i));
            }
            estado = Estado.CONSULTAR_TRANSACCIONES;
        }
    }
    
    /**
     * Funcion que se lleva a cabo al pulsar el boton de salir.
     * Si el estado de la interfaz es sin tarjeta pide al usuario por pantalla que
     * introduzca la tarjeta.
     * Si el estado es cualquiera que no sea sin tarjeta el cajero extrae la tarjeta
     * y pide al usuario que la retire.
     */
    public void procesarEventoBotonSalir(){
        if(estado.equals(Estado.SIN_TARJETA)){
            vista.setTextPantalla("Introduzca una tarjeta");
        }else{
            estado = Estado.CON_TARJETA;
            vista.setTextPantalla("Porfavor retire la tarjeta");
            vista.setEnabledToggleButtonTarjeta(true);
            vista.desactivarLabels();
            vista.clearTextTransacciones();
            vista.setEnabledAllButtons(false);
        }
    }
    
}
