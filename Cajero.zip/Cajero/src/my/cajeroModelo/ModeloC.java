package my.cajeroModelo;

import java.util.ArrayList;
import my.cajeroVista.Estado;

/**
 *
 * @author Oscar Saez Gonzalez
 * @author Jacobo Muñoz Martinez
 * 
 * Clase modelo que contiene la informacion privada del programa
 */
public class ModeloC {
    
    public String pinCorrecto;
    public int saldo;
    public ArrayList<String> transacciones = new ArrayList<>();
    
    /**
     * Constructor de la clase ModeloC
     */
    public ModeloC(){
        pinCorrecto = "1234";
        saldo = 500;
        transacciones.add("Retirada de 100€ realizada el 10/01/2022");
        transacciones.add("Retirada de 200€ realizada el 12/02/2022");
    }
    
    /**
     * Devuelve el pin correcto de la tarjeta
     * @return pin correcto
     */
    public String getPinCorrecto(){
        return pinCorrecto;
    }
    
    /**
     * Devuelve el saldo de la tarjeta
     * @return saldo
     */
    public int getSaldo(){
        return saldo;
    }
    
    /**
     * Devuelve la lista de transacciones en un ArrayList
     * @return transacciones
     */
    public ArrayList<String> getTransacciones(){
        return transacciones;
    }
    
    /**
     * Modifica el saldo de la tarjeta
     * @param n (dinero)
     */
    public void setSaldo(int n){
        saldo = n;
    }
    
    /**
     * Introduce una nueva transaccion en la lista de transacciones
     * @param s (nueva transaccion)
     */
    public void addTransaccion(String s){
        transacciones.add(s);
    }
}
